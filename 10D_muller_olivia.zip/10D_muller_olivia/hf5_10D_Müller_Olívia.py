with open("10d_csipak_miklos\input.txt" , "r") as file:
    raw = ""
    for line in file:
        raw += line

char = " "
sorz = [list(map(int, x.split(char))) for x in raw.splitlines()]

elso,masodik,harmadik,negyedik,otodik = sorz

print("2. feladat")
valasz = [x for x in elso if x < 14]
valasz = sum(valasz) / len(valasz)
print("Az 1. sorban szereplő 14-nél kisebb számok számtani közepe:", valasz)

print("3. feladat")
valasz = max([x for x in masodik if x > 14])
print("Az 2. sorban szereplő 14-nél nagyobb számok maximuma:", valasz)

print("4. feladat")
valasz = sum([x**2 for x in harmadik])
print("Az 3. sorban szereplő számok négyzeteinek összege:", valasz)

print("5. feladat")
valasz = min([x for x in negyedik if x % 2 == 0])
print("Az 4. sorban szereplő páros számok minimuma:", valasz)

print("6. feladat")
s = 1
for szam in sorted(otodik)[0:15]:
    s *= szam
valasz = "10^" + str(len(str(s)) - 1)
print("Az 5. sorban szereplő 15 legkisebb szám szorzatának nagyságrendje:", valasz)

print("7. feladat")
valasz = sum(sorted((elso + masodik + harmadik + negyedik + otodik))[-10:])
print("Az inputban szereplő összes szám közül a 10 legnagyobb szám összege:", valasz)